// ABCU Course Planner - Algorithms and Data Structures Enhancement
// Author: Steven Valiant Burgett | CS 499 Milestone Three | September 2026
// Self-balancing AVL tree and recursive prerequisite traversal.
#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <memory>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

struct Course {
    string number, title;
    vector<string> prerequisites;
};

string trim(const string& s) {
    const auto first = s.find_first_not_of(" \t\r\n");
    if (first == string::npos) return "";
    return s.substr(first, s.find_last_not_of(" \t\r\n") - first + 1);
}
string normalize(string s) {
    s = trim(s);
    transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(toupper(c)); });
    return s;
}

class AVLTree {
    struct Node {
        Course course;
        unique_ptr<Node> left, right;
        int height = 1;
        explicit Node(Course c) : course(std::move(c)) {}
    };
    unique_ptr<Node> root;
    static int height(const unique_ptr<Node>& n) { return n ? n->height : 0; }
    static void update(Node* n) { n->height = 1 + max(height(n->left), height(n->right)); }
    static int balance(const Node* n) { return height(n->left) - height(n->right); }
    static unique_ptr<Node> rotateRight(unique_ptr<Node> y) {
        auto x = std::move(y->left);
        y->left = std::move(x->right);
        update(y.get());
        x->right = std::move(y);
        update(x.get());
        return x;
    }
    static unique_ptr<Node> rotateLeft(unique_ptr<Node> x) {
        auto y = std::move(x->right);
        x->right = std::move(y->left);
        update(x.get());
        y->left = std::move(x);
        update(y.get());
        return y;
    }
    static unique_ptr<Node> insert(unique_ptr<Node> n, const Course& c, bool& added) {
        if (!n) { added = true; return make_unique<Node>(c); }
        if (c.number < n->course.number) n->left = insert(std::move(n->left), c, added);
        else if (c.number > n->course.number) n->right = insert(std::move(n->right), c, added);
        else return n; // Duplicate IDs are skipped so lookup stays unambiguous.
        update(n.get());
        if (balance(n.get()) > 1) {
            if (balance(n->left.get()) < 0) n->left = rotateLeft(std::move(n->left));
            return rotateRight(std::move(n));
        }
        if (balance(n.get()) < -1) {
            if (balance(n->right.get()) > 0) n->right = rotateRight(std::move(n->right));
            return rotateLeft(std::move(n));
        }
        return n;
    }
    static void print(const Node* n) {
        if (!n) return;
        print(n->left.get());
        cout << n->course.number << ", " << n->course.title << '\n';
        print(n->right.get());
    }
public:
    bool add(const Course& c) { bool added = false; root = insert(std::move(root), c, added); return added; }
    const Course* find(const string& key) const {
        const Node* n = root.get();
        while (n) {
            if (key == n->course.number) return &n->course;
            n = (key < n->course.number) ? n->left.get() : n->right.get();
        }
        return nullptr;
    }
    void printSorted() const { print(root.get()); }
    int treeHeight() const { return height(root); }
};

// active identifies a back edge (cycle); shown prevents repeated expansion in a DAG.
void printPrerequisites(const AVLTree& tree, const Course& course,
                        set<string>& active, set<string>& shown, int depth) {
    for (const string& id : course.prerequisites) {
        cout << string(depth * 2, ' ') << "- " << id;
        if (active.count(id)) { cout << " [cycle detected]\n"; continue; }
        const Course* next = tree.find(id);
        if (!next) { cout << " [course not found]\n"; continue; }
        cout << ", " << next->title;
        if (shown.count(id)) { cout << " [already shown]\n"; continue; }
        cout << '\n';
        shown.insert(id);
        active.insert(id);
        printPrerequisites(tree, *next, active, shown, depth + 1);
        active.erase(id);
    }
}

void loadCourses(const string& filename, AVLTree& tree) {
    ifstream file(filename);
    if (!file) { cout << "Error: Could not open file: " << filename << '\n'; return; }
    string line;
    int loaded = 0, skipped = 0;
    while (getline(file, line)) {
        if (trim(line).empty()) continue;
        stringstream ss(line);
        string id, title, token;
        getline(ss, id, ','); getline(ss, title, ',');
        Course c{normalize(id), trim(title), {}};
        if (c.number.empty() || c.title.empty()) { ++skipped; continue; }
        while (getline(ss, token, ',')) {
            token = normalize(token);
            if (!token.empty()) c.prerequisites.push_back(token);
        }
        if (tree.add(c)) ++loaded; else ++skipped;
    }
    cout << "Loaded " << loaded << " courses; skipped " << skipped
         << " invalid or duplicate rows. Tree height: " << tree.treeHeight() << ".\n";
}

int main() {
    AVLTree tree;
    cout << "Welcome to the course planner.\n";
    string choice, value;
    while (true) {
        cout << "\n1. Load Data Structure\n2. Print Course List\n3. Print Course\n9. Exit\n"
             << "What would you like to do? ";
        if (!getline(cin, choice)) break;
        choice = trim(choice);
        if (choice == "9") { cout << "Thank you for using the course planner!\n"; break; }
        if (choice == "1") {
            cout << "Enter CSV file name: ";
            if (!getline(cin, value)) break;
            loadCourses(trim(value), tree);
        } else if (choice == "2") tree.printSorted();
        else if (choice == "3") {
            cout << "What course do you want to know about? ";
            if (!getline(cin, value)) break;
            const Course* course = tree.find(normalize(value));
            if (!course) { cout << "Course not found.\n"; continue; }
            cout << course->number << ", " << course->title << '\n';
            if (course->prerequisites.empty()) cout << "Prerequisites: None\n";
            else {
                cout << "Complete prerequisite paths:\n";
                set<string> active{course->number}, shown;
                printPrerequisites(tree, *course, active, shown, 1);
            }
        } else cout << "Invalid option. Enter 1, 2, 3, or 9.\n";
    }
    return 0;
}
