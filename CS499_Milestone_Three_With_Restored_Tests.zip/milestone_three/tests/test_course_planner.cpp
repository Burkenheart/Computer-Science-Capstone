// Automated regression tests for the submitted CS 499 Milestone Three Course Planner.
// Include the implementation while renaming its interactive main entry point.
#define main course_planner_interactive_main
#include "../enhanced/ABCUCoursePlanner_AVL.cpp"
#undef main
#include <cstdio>
#include <functional>
#include <stdexcept>
#include <utility>

static void require(bool ok, const string& message) {
    if (!ok) throw runtime_error(message);
}
static Course course(const string& id, vector<string> prerequisites = {}) {
    return Course{id, "Title " + id, std::move(prerequisites)};
}
static string capture(const function<void()>& fn) {
    ostringstream output;
    auto* previous = cout.rdbuf(output.rdbuf());
    try { fn(); } catch (...) { cout.rdbuf(previous); throw; }
    cout.rdbuf(previous);
    return output.str();
}
static string tempFile(const string& data) {
    static int counter = 0;
    string path = "course_planner_test_" + to_string(++counter) + ".csv";
    ofstream file(path);
    require(bool(file), "Cannot create temporary CSV");
    file << data;
    return path;
}
static string load(AVLTree& tree, const string& data) {
    const string path = tempFile(data);
    const string result = capture([&] { loadCourses(path, tree); });
    remove(path.c_str());
    return result;
}
static string prerequisites(const AVLTree& tree, const string& id) {
    const Course* c = tree.find(id);
    require(c != nullptr, "Missing course " + id);
    set<string> active{id}, shown;
    return capture([&] { printPrerequisites(tree, *c, active, shown, 1); });
}
int main() {
    vector<pair<string, function<void()>>> tests;
    auto test = [&](string name, function<void()> fn) { tests.emplace_back(std::move(name), std::move(fn)); };
    test("trim whitespace", [] { require(trim(" \t CS300 \r\n") == "CS300", "trim failed"); });
    test("normalize ID", [] { require(normalize(" cs300 ") == "CS300", "normalize failed"); });
    test("empty tree", [] { AVLTree t; require(t.treeHeight() == 0 && !t.find("X"), "empty tree"); });
    test("single insertion", [] { AVLTree t; require(t.add(course("B")) && t.treeHeight() == 1 && t.find("B"), "insert"); });
    test("duplicate preserves first", [] { AVLTree t; t.add(Course{"A", "First", {}}); require(!t.add(Course{"A", "Second", {}}) && t.find("A")->title == "First", "duplicate"); });
    test("LL rotation", [] { AVLTree t; for (auto id : {"C","B","A"}) t.add(course(id)); require(t.treeHeight() == 2, "LL height"); });
    test("RR rotation", [] { AVLTree t; for (auto id : {"A","B","C"}) t.add(course(id)); require(t.treeHeight() == 2, "RR height"); });
    test("LR rotation", [] { AVLTree t; for (auto id : {"C","A","B"}) t.add(course(id)); require(t.treeHeight() == 2, "LR height"); });
    test("RL rotation", [] { AVLTree t; for (auto id : {"A","C","B"}) t.add(course(id)); require(t.treeHeight() == 2, "RL height"); });
    test("balanced bulk insertion", [] { AVLTree t; for (int i=0;i<100;++i) t.add(course("C"+to_string(100+i))); require(t.treeHeight() <= 8, "height too large"); });
    test("bulk lookup", [] { AVLTree t; for (int i=0;i<100;++i) t.add(course("C"+to_string(100+i))); require(t.find("C150") && !t.find("C999"), "lookup"); });
    test("sorted traversal", [] { AVLTree t; for (auto id : {"C","A","B"}) t.add(course(id)); auto s=capture([&]{t.printSorted();}); require(s.find("A,") < s.find("B,") && s.find("B,") < s.find("C,"), "order"); });
    test("CSV loads and normalizes", [] { AVLTree t; auto s=load(t," cs100 , Intro \nCS200, Advanced, cs100\n"); require(t.find("CS100") && t.find("CS200") && t.find("CS200")->prerequisites[0] == "CS100" && s.find("Loaded 2") != string::npos, "CSV"); });
    test("CSV skips empty ID", [] { AVLTree t; auto s=load(t,",Untitled\nCS100,Valid\n"); require(!t.find("") && t.find("CS100") && s.find("skipped 1") != string::npos, "empty ID"); });
    test("CSV skips empty title", [] { AVLTree t; auto s=load(t,"CS100, \nCS200,Valid\n"); require(!t.find("CS100") && t.find("CS200") && s.find("skipped 1") != string::npos, "empty title"); });
    test("CSV duplicate ID skipped", [] { AVLTree t; auto s=load(t,"CS100,First\ncs100,Second\n"); require(t.find("CS100") && t.find("CS100")->title == "First" && s.find("skipped 1") != string::npos, "duplicate CSV"); });
    test("CSV repeated load preserves first", [] { AVLTree t; load(t,"CS100,First\n"); load(t,"CS100,Second\nCS200,New\n"); require(t.find("CS100")->title == "First" && t.find("CS200"), "repeated load"); });
    test("recursive prerequisites", [] { AVLTree t; t.add(course("A")); t.add(course("B",{"A"})); t.add(course("C",{"B"})); auto s=prerequisites(t,"C"); require(s.find("- B") != string::npos && s.find("- A") != string::npos, "recursive path"); });
    test("missing prerequisite reference", [] { AVLTree t; t.add(course("A",{"MISSING"})); require(prerequisites(t,"A").find("[course not found]") != string::npos, "missing reference"); });
    test("cycle detection", [] { AVLTree t; t.add(course("A",{"B"})); t.add(course("B",{"A"})); require(prerequisites(t,"A").find("[cycle detected]") != string::npos, "cycle"); });

    int passed=0;
    for (const auto& entry : tests) {
        try { entry.second(); cout << "[PASS] " << entry.first << '\n'; ++passed; }
        catch (const exception& e) { cerr << "[FAIL] " << entry.first << ": " << e.what() << '\n'; }
    }
    cout << "Results: " << passed << "/" << tests.size() << " passed; " << (tests.size()-passed) << " failed.\n";
    return passed == int(tests.size()) ? 0 : 1;
}
