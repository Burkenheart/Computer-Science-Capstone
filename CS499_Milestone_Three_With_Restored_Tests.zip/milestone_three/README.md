# CS 499 Milestone Three: ABCU Course Planner

- `original/ABCUProjectTwo_original.cpp`: unchanged CS 300 source artifact.
- `enhanced/ABCUCoursePlanner_AVL.cpp`: CS 499 enhancement.
- `tests/courses.csv`: sample data covering recursive paths, repeated dependencies, a missing reference, a cycle, and a duplicate ID.

Compile with `g++ -std=c++17 -Wall -Wextra -pedantic enhanced/ABCUCoursePlanner_AVL.cpp -o abcu_planner` and run `./abcu_planner`. Select option 1 and enter `tests/courses.csv` when running from this directory. Select option 3 for `CS400`, `CS500`, or `CS600` to inspect the three special cases. A CSV row has a course number, title, and zero or more prerequisite course numbers. Quoted commas are not supported, matching the original format.

The AVL tree updates node heights and applies single or double rotations after insertion. It maintains O(log n) worst-case height and therefore O(log n) search and insertion. Sorted traversal is O(n). Prerequisite traversal visits each reachable course at most once, with an AVL lookup for each prerequisite edge: O((V + E) log n) in the reachable dependency graph. Recursion uses O(depth) stack space; cyclic edges are reported. Duplicate IDs are skipped, and repeated loads retain existing records.

AI acknowledgment: ChatGPT assisted with implementation, test data, and documentation. The author should review and understand all submitted code and descriptions.

## Automated regression tests (restored October 2026)

From the `milestone_three` directory on Windows, with `g++` on your PATH, run:

```powershell
.\run_tests.ps1
```

The script compiles `tests/test_course_planner.cpp` against the enhanced implementation and runs **20 regression tests**. The tests cover AVL rotations and height, lookup, sorted output, normalization, CSV loading and duplicate handling, recursive prerequisites, missing references, and cycle detection. They test the **submitted implementation as written**; they do not prove atomic file loads, comprehensive malformed CSV rejection, or other behavior not implemented in the submitted code. A successful run reports `Results: 20/20 passed; 0 failed.`

AI acknowledgment: ChatGPT assisted in restoring the regression test harness and PowerShell runner. Review the tests and run them locally before citing new verification results.
