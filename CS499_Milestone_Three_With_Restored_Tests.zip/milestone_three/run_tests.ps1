# Run from the milestone_three directory on Windows PowerShell.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command g++ -ErrorAction SilentlyContinue)) {
    Write-Error 'g++ was not found. Open an MSYS2 UCRT64 terminal or add its bin directory to PATH.'
    exit 1
}
$exe = Join-Path $PSScriptRoot 'course_planner_tests.exe'
& g++ -std=c++17 -Wall -Wextra -pedantic tests/test_course_planner.cpp -o $exe
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
& $exe
if ($LASTEXITCODE -ne 0) { throw 'One or more tests failed.' }
