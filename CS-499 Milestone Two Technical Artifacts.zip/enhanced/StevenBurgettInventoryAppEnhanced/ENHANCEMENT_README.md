# CS 499 Software Design and Engineering Enhancement

## Artifact

The enhanced artifact is Steven Burgett's CS 360 Inventory Management Tracker,
an Android application written in Java with local SQLite storage and optional
SMS low-inventory alerts.

## Completed Enhancements

- Added `User` and `InventoryItem` domain models.
- Added `UserRepository` and `InventoryRepository` so activities no longer
  perform direct SQLite queries.
- Replaced plaintext password storage with unique random salts and
  PBKDF2-HMAC-SHA256 password hashes.
- Added centralized credential and inventory validation.
- Added SQLite constraints for nonnegative quantities and thresholds.
- Added a configurable low-stock threshold to every inventory item.
- Added indexed, case-insensitive inventory search with safe query arguments.
- Preserved inventory CRUD operations and optional SMS alerts.
- Added focused validation unit tests and professional file documentation.

## Upgrade Note

Database version 2 preserves existing inventory records and assigns the
original default threshold of five. Existing version 1 user accounts are
removed during migration because their plaintext passwords cannot be retained
safely; users create a new securely stored account after upgrading.

## Verification

Open the project in Android Studio, allow Gradle sync to complete, and run the
`testDebugUnitTest` task followed by the app on an emulator or Android device.
Verify account creation and login, inventory add/edit/delete, search, individual
threshold warnings, and both accepted and declined SMS permission paths.
