package com.example.stevenburgettinventoryapp;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import com.example.stevenburgettinventoryapp.validation.InputValidator;
import org.junit.Test;

/** Unit tests for security and inventory input boundaries. */
public class InputValidatorTest {
    @Test public void validAccountCredentialsAreAccepted() {
        assertNull(InputValidator.validateCredentials("steven.b", "SecurePass1", true));
    }

    @Test public void shortNewPasswordIsRejected() {
        assertNotNull(InputValidator.validateCredentials("steven.b", "short", true));
    }

    @Test public void negativeQuantityIsRejected() {
        assertNotNull(InputValidator.validateInventory("Radio", -1, 5));
    }

    @Test public void independentThresholdIsAccepted() {
        assertNull(InputValidator.validateInventory("Radio", 12, 3));
    }
}
