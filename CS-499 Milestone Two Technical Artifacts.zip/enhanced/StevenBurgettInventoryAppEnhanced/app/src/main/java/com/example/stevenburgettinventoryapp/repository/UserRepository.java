package com.example.stevenburgettinventoryapp.repository;

import android.content.ContentValues;
import android.database.Cursor;
import com.example.stevenburgettinventoryapp.DatabaseHelper;
import com.example.stevenburgettinventoryapp.model.User;
import com.example.stevenburgettinventoryapp.security.PasswordHasher;

/**
 * Author: Steven Burgett | CS 499 | September 2026
 * Provides account creation and authentication without exposing SQLite to the UI.
 */
public final class UserRepository {
    private final DatabaseHelper database;
    private final PasswordHasher passwordHasher = new PasswordHasher();
    public UserRepository(DatabaseHelper database) { this.database = database; }

    public boolean createAccount(String username, String password) {
        PasswordHasher.HashResult protectedPassword = passwordHasher.hash(password);
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.USER_USERNAME, username.trim());
        values.put(DatabaseHelper.USER_PASSWORD_HASH, protectedPassword.getHash());
        values.put(DatabaseHelper.USER_PASSWORD_SALT, protectedPassword.getSalt());
        return database.insertUser(values) != -1;
    }

    public User authenticate(String username, String password) {
        try (Cursor cursor = database.findUserByUsername(username.trim())) {
            if (!cursor.moveToFirst()) return null;
            String hash = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.USER_PASSWORD_HASH));
            String salt = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.USER_PASSWORD_SALT));
            if (!passwordHasher.verify(password, hash, salt)) return null;
            return new User(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.USER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.USER_USERNAME)));
        }
    }
}
