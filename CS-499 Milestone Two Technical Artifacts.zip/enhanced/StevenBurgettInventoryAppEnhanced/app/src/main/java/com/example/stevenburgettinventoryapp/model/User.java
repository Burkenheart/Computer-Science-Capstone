package com.example.stevenburgettinventoryapp.model;

/**
 * Author: Steven Burgett | CS 499 | September 2026
 * Immutable user record returned by the authentication repository.
 */
public final class User {
    private final int id;
    private final String username;

    public User(int id, String username) { this.id = id; this.username = username; }
    public int getId() { return id; }
    public String getUsername() { return username; }
}
