package com.example.stevenburgettinventoryapp.security;

import android.util.Base64;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Author: Steven Burgett | CS 499 | September 2026
 * Protects passwords with a unique random salt and PBKDF2-HMAC-SHA256.
 */
public final class PasswordHasher {
    private static final int ITERATIONS = 120_000;
    private static final int KEY_LENGTH_BITS = 256;
    private static final int SALT_LENGTH_BYTES = 16;

    public static final class HashResult {
        private final String hash;
        private final String salt;
        public HashResult(String hash, String salt) { this.hash = hash; this.salt = salt; }
        public String getHash() { return hash; }
        public String getSalt() { return salt; }
    }

    public HashResult hash(String password) {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        new SecureRandom().nextBytes(salt);
        byte[] hash = deriveKey(password.toCharArray(), salt);
        return new HashResult(Base64.encodeToString(hash, Base64.NO_WRAP),
                Base64.encodeToString(salt, Base64.NO_WRAP));
    }

    public boolean verify(String password, String expectedHash, String encodedSalt) {
        byte[] actual = deriveKey(password.toCharArray(),
                Base64.decode(encodedSalt, Base64.NO_WRAP));
        byte[] expected = Base64.decode(expectedHash, Base64.NO_WRAP);
        if (actual.length != expected.length) return false;
        int difference = 0;
        for (int index = 0; index < actual.length; index++) difference |= actual[index] ^ expected[index];
        return difference == 0;
    }

    private byte[] deriveKey(char[] password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException("Password hashing is unavailable.", exception);
        } finally {
            spec.clearPassword();
        }
    }
}
