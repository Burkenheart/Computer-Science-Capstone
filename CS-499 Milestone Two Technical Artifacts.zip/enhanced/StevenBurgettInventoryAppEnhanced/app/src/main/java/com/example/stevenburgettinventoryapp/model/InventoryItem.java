package com.example.stevenburgettinventoryapp.model;

/**
 * Author: Steven Burgett | CS 499 | September 2026
 * Represents one inventory record and its individual low-stock threshold.
 */
public final class InventoryItem {
    private final int id;
    private final String name;
    private final int quantity;
    private final int lowThreshold;

    public InventoryItem(int id, String name, int quantity, int lowThreshold) {
        this.id = id; this.name = name; this.quantity = quantity; this.lowThreshold = lowThreshold;
    }
    public int getId() { return id; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public int getLowThreshold() { return lowThreshold; }
    public boolean isLowStock() { return quantity <= lowThreshold; }
}
