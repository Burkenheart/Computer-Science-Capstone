package com.example.stevenburgettinventoryapp.repository;

import android.content.ContentValues;
import android.database.Cursor;
import com.example.stevenburgettinventoryapp.DatabaseHelper;
import com.example.stevenburgettinventoryapp.model.InventoryItem;
import java.util.ArrayList;
import java.util.List;

/**
 * Author: Steven Burgett | CS 499 | September 2026
 * Provides inventory operations and converts database rows into domain models.
 */
public final class InventoryRepository {
    private final DatabaseHelper database;
    public InventoryRepository(DatabaseHelper database) { this.database = database; }

    public boolean add(InventoryItem item) { return database.insertInventoryItem(toValues(item)) != -1; }
    public List<InventoryItem> search(String term) {
        List<InventoryItem> items = new ArrayList<>();
        try (Cursor cursor = database.queryInventory(term)) {
            while (cursor.moveToNext()) {
                items.add(new InventoryItem(
                        cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.ITEM_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.ITEM_NAME)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.ITEM_QUANTITY)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.ITEM_LOW_THRESHOLD))));
            }
        }
        return items;
    }
    public boolean update(InventoryItem item) {
        return database.updateInventoryItem(item.getId(), toValues(item)) > 0;
    }
    public boolean delete(int id) { return database.deleteInventoryItem(id) > 0; }
    private ContentValues toValues(InventoryItem item) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.ITEM_NAME, item.getName().trim());
        values.put(DatabaseHelper.ITEM_QUANTITY, item.getQuantity());
        values.put(DatabaseHelper.ITEM_LOW_THRESHOLD, item.getLowThreshold());
        return values;
    }
}
