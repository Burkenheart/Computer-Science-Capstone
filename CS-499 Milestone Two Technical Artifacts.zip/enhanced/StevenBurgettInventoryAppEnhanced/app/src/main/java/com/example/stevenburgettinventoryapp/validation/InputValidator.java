package com.example.stevenburgettinventoryapp.validation;

import java.util.regex.Pattern;

/**
 * Author: Steven Burgett | CS 499 | September 2026
 * Centralizes validation rules used by the UI and repository layers.
 */
public final class InputValidator {
    public static final int MAX_QUANTITY = 1_000_000;
    private static final Pattern USERNAME_PATTERN = Pattern.compile("[A-Za-z0-9._-]{3,40}");
    private InputValidator() { }

    public static String validateCredentials(String username, String password, boolean newAccount) {
        if (username == null || !USERNAME_PATTERN.matcher(username.trim()).matches())
            return "Username must be 3-40 characters and use only letters, numbers, periods, underscores, or hyphens.";
        if (password == null || password.isEmpty()) return "Password is required.";
        if (newAccount && password.length() < 8) return "Password must contain at least 8 characters.";
        if (password.length() > 128) return "Password cannot exceed 128 characters.";
        return null;
    }

    public static String validateInventory(String name, int quantity, int threshold) {
        if (name == null || name.trim().isEmpty()) return "Equipment name is required.";
        if (name.trim().length() > 80) return "Equipment name cannot exceed 80 characters.";
        if (quantity < 0 || quantity > MAX_QUANTITY) return "Quantity must be between 0 and 1,000,000.";
        if (threshold < 0 || threshold > MAX_QUANTITY)
            return "Low-stock threshold must be between 0 and 1,000,000.";
        return null;
    }
}
