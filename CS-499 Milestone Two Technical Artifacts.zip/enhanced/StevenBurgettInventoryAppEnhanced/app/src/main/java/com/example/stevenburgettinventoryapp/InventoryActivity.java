package com.example.stevenburgettinventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.example.stevenburgettinventoryapp.model.InventoryItem;
import com.example.stevenburgettinventoryapp.repository.InventoryRepository;
import com.example.stevenburgettinventoryapp.validation.InputValidator;
import java.util.List;

/**
 * Author: Steven Burgett
 * Course: CS 499 Computer Science Capstone
 * Enhancement: Software Design and Engineering, September 2026
 *
 * Controls inventory-screen interactions. Domain models and a repository keep
 * business data and SQLite operations separate from presentation logic.
 */
public class InventoryActivity extends AppCompatActivity {
    private static final String PREFS_NAME = "InventoryPreferences";
    private static final String SMS_ENABLED_KEY = "sms_enabled";
    private static final String PHONE_NUMBER_KEY = "phone_number";

    private InventoryRepository inventoryRepository;
    private EditText editItemName;
    private EditText editItemQuantity;
    private EditText editLowThreshold;
    private EditText editSearch;
    private TableLayout tableInventory;
    private TextView textLowInventory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        inventoryRepository = new InventoryRepository(new DatabaseHelper(this));

        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        editLowThreshold = findViewById(R.id.editLowThreshold);
        editSearch = findViewById(R.id.editSearch);
        tableInventory = findViewById(R.id.tableInventory);
        textLowInventory = findViewById(R.id.textLowInventory);

        findViewById(R.id.buttonAddItem).setOnClickListener(view -> addInventoryItem());
        findViewById(R.id.buttonClearSearch).setOnClickListener(view -> editSearch.setText(""));
        findViewById(R.id.buttonSmsSettings).setOnClickListener(view ->
                startActivity(new Intent(this, SmsPermissionActivity.class)));
        findViewById(R.id.buttonLogout).setOnClickListener(view -> logout());

        editSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadInventory(s.toString());
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        loadInventory("");
    }

    private void addInventoryItem() {
        InventoryItem item = readInventoryInput(0, editItemName, editItemQuantity, editLowThreshold);
        if (item == null) return;
        if (!inventoryRepository.add(item)) {
            showMessage("Unable to add inventory item.");
            return;
        }
        showMessage("Inventory item added.");
        if (item.isLowStock()) sendLowInventorySms(item);
        editItemName.setText("");
        editItemQuantity.setText("");
        editLowThreshold.setText("5");
        loadInventory(editSearch.getText().toString());
    }

    private InventoryItem readInventoryInput(int id, EditText nameInput,
                                              EditText quantityInput, EditText thresholdInput) {
        String name = nameInput.getText().toString().trim();
        int quantity;
        int threshold;
        try {
            quantity = Integer.parseInt(quantityInput.getText().toString().trim());
            threshold = Integer.parseInt(thresholdInput.getText().toString().trim());
        } catch (NumberFormatException exception) {
            showMessage("Quantity and low-stock threshold must be whole numbers.");
            return null;
        }
        String error = InputValidator.validateInventory(name, quantity, threshold);
        if (error != null) {
            showMessage(error);
            return null;
        }
        return new InventoryItem(id, name, quantity, threshold);
    }

    private void loadInventory(String searchTerm) {
        while (tableInventory.getChildCount() > 1) tableInventory.removeViewAt(1);
        List<InventoryItem> items = inventoryRepository.search(searchTerm);
        StringBuilder lowItems = new StringBuilder();
        for (InventoryItem item : items) {
            addInventoryRow(item);
            if (item.isLowStock()) {
                if (lowItems.length() == 0) lowItems.append("Low inventory: ");
                else lowItems.append(", ");
                lowItems.append(item.getName()).append(" (")
                        .append(item.getQuantity()).append("/")
                        .append(item.getLowThreshold()).append(")");
            }
        }
        if (items.isEmpty() && searchTerm != null && !searchTerm.trim().isEmpty()) {
            textLowInventory.setText("No inventory items match your search.");
        } else {
            textLowInventory.setText(lowItems.length() == 0
                    ? "No low inventory warnings." : lowItems.toString());
        }
    }

    private void addInventoryRow(InventoryItem item) {
        TableRow row = new TableRow(this);
        row.setPadding(8, 8, 8, 8);
        row.addView(makeCell(item.getName(), 2f, Gravity.START));
        row.addView(makeCell(String.valueOf(item.getQuantity()), 1f, Gravity.CENTER));
        row.addView(makeCell(String.valueOf(item.getLowThreshold()), 1f, Gravity.CENTER));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        actions.setLayoutParams(new TableRow.LayoutParams(0,
                TableRow.LayoutParams.WRAP_CONTENT, 2f));
        Button edit = new Button(this);
        edit.setText("Edit");
        edit.setTextSize(10);
        edit.setOnClickListener(view -> showEditDialog(item));
        Button delete = new Button(this);
        delete.setText("Delete");
        delete.setTextSize(10);
        delete.setOnClickListener(view -> confirmDelete(item));
        actions.addView(edit);
        actions.addView(delete);
        row.addView(actions);
        tableInventory.addView(row);
    }

    private TextView makeCell(String value, float weight, int gravity) {
        TextView cell = new TextView(this);
        cell.setText(value);
        cell.setGravity(gravity);
        cell.setLayoutParams(new TableRow.LayoutParams(0,
                TableRow.LayoutParams.WRAP_CONTENT, weight));
        return cell;
    }

    private void showEditDialog(InventoryItem current) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 24, 40, 8);
        EditText name = dialogField("Equipment name", InputType.TYPE_CLASS_TEXT,
                current.getName());
        EditText quantity = dialogField("Quantity", InputType.TYPE_CLASS_NUMBER,
                String.valueOf(current.getQuantity()));
        EditText threshold = dialogField("Low-stock threshold", InputType.TYPE_CLASS_NUMBER,
                String.valueOf(current.getLowThreshold()));
        layout.addView(name);
        layout.addView(quantity);
        layout.addView(threshold);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Inventory Item")
                .setView(layout)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    InventoryItem updated = readInventoryInput(current.getId(), name, quantity, threshold);
                    if (updated == null) return;
                    if (!inventoryRepository.update(updated)) {
                        showMessage("Unable to update inventory item.");
                        return;
                    }
                    if (updated.isLowStock() && !current.isLowStock()) sendLowInventorySms(updated);
                    showMessage("Inventory item updated.");
                    dialog.dismiss();
                    loadInventory(editSearch.getText().toString());
                }));
        dialog.show();
    }

    private EditText dialogField(String hint, int inputType, String value) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setInputType(inputType);
        field.setText(value);
        return field;
    }

    private void confirmDelete(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Inventory Item")
                .setMessage("Delete " + item.getName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    showMessage(inventoryRepository.delete(item.getId())
                            ? "Inventory item deleted." : "Unable to delete inventory item.");
                    loadInventory(editSearch.getText().toString());
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendLowInventorySms(InventoryItem item) {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean enabled = preferences.getBoolean(SMS_ENABLED_KEY, false);
        String phoneNumber = preferences.getString(PHONE_NUMBER_KEY, "");
        if (!enabled || phoneNumber == null || phoneNumber.isEmpty()) return;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) return;
        String message = "Inventory Alert: " + item.getName() + " has " +
                item.getQuantity() + " remaining (threshold " + item.getLowThreshold() + ").";
        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
            showMessage("Low inventory SMS alert sent.");
        } catch (RuntimeException exception) {
            showMessage("Unable to send SMS alert.");
        }
    }

    private void logout() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (inventoryRepository != null && editSearch != null)
            loadInventory(editSearch.getText().toString());
    }
}
