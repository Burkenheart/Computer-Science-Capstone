package com.example.stevenburgettinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.stevenburgettinventoryapp.model.User;
import com.example.stevenburgettinventoryapp.repository.UserRepository;
import com.example.stevenburgettinventoryapp.validation.InputValidator;

/**
 * Author: Steven Burgett
 * Course: CS 499 Computer Science Capstone
 * Enhancement: Software Design and Engineering, September 2026
 *
 * Presents authentication controls while delegating credential storage and
 * verification to UserRepository.
 */
public class MainActivity extends AppCompatActivity {
    private EditText editUsername;
    private EditText editPassword;
    private UserRepository userRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        userRepository = new UserRepository(new DatabaseHelper(this));

        buttonLogin.setOnClickListener(view -> loginUser());
        buttonCreateAccount.setOnClickListener(view -> createAccount());
    }

    private void loginUser() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();
        String error = InputValidator.validateCredentials(username, password, false);
        if (error != null) {
            showMessage(error);
            return;
        }

        User user = userRepository.authenticate(username, password);
        editPassword.setText("");
        if (user == null) {
            showMessage("Invalid username or password.");
            return;
        }

        Intent intent = new Intent(this, InventoryActivity.class);
        intent.putExtra("signed_in_username", user.getUsername());
        startActivity(intent);
    }

    private void createAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();
        String error = InputValidator.validateCredentials(username, password, true);
        if (error != null) {
            showMessage(error);
            return;
        }

        boolean created = userRepository.createAccount(username, password);
        editPassword.setText("");
        showMessage(created
                ? "Account created. You can now log in."
                : "That username already exists.");
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
