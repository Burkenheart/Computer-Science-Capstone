package com.example.stevenburgettinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Author: Steven Burgett
 * Course: CS 499 Computer Science Capstone
 * Enhancement: Software Design and Engineering, September 2026
 *
 * Owns the SQLite schema and low-level database operations. Activities do not
 * access this class directly; repositories provide the application-facing API.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_USERS = "users";
    public static final String USER_ID = "id";
    public static final String USER_USERNAME = "username";
    public static final String USER_PASSWORD_HASH = "password_hash";
    public static final String USER_PASSWORD_SALT = "password_salt";
    public static final String TABLE_INVENTORY = "inventory";
    public static final String ITEM_ID = "id";
    public static final String ITEM_NAME = "name";
    public static final String ITEM_QUANTITY = "quantity";
    public static final String ITEM_LOW_THRESHOLD = "low_threshold";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createUsersTable(db);
        createInventoryTable(db);
    }

    private void createUsersTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USER_USERNAME + " TEXT UNIQUE NOT NULL COLLATE NOCASE, " +
                USER_PASSWORD_HASH + " TEXT NOT NULL, " +
                USER_PASSWORD_SALT + " TEXT NOT NULL)");
    }

    private void createInventoryTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_INVENTORY + " (" +
                ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ITEM_NAME + " TEXT NOT NULL COLLATE NOCASE, " +
                ITEM_QUANTITY + " INTEGER NOT NULL CHECK(" + ITEM_QUANTITY + " >= 0), " +
                ITEM_LOW_THRESHOLD + " INTEGER NOT NULL DEFAULT 5 CHECK(" +
                ITEM_LOW_THRESHOLD + " >= 0))");
        db.execSQL("CREATE INDEX idx_inventory_name ON " +
                TABLE_INVENTORY + "(" + ITEM_NAME + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.beginTransaction();
        try {
            if (oldVersion < 2) {
                // Plaintext credentials cannot be retained safely. Recreate only
                // the users table and require account creation after the upgrade.
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
                createUsersTable(db);
                db.execSQL("ALTER TABLE " + TABLE_INVENTORY + " ADD COLUMN " +
                        ITEM_LOW_THRESHOLD + " INTEGER NOT NULL DEFAULT 5");
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_inventory_name ON " +
                        TABLE_INVENTORY + "(" + ITEM_NAME + ")");
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public long insertUser(ContentValues values) {
        return getWritableDatabase().insert(TABLE_USERS, null, values);
    }

    public Cursor findUserByUsername(String username) {
        return getReadableDatabase().query(TABLE_USERS,
                new String[]{USER_ID, USER_USERNAME, USER_PASSWORD_HASH, USER_PASSWORD_SALT},
                USER_USERNAME + " = ?", new String[]{username}, null, null, null, "1");
    }

    public long insertInventoryItem(ContentValues values) {
        return getWritableDatabase().insert(TABLE_INVENTORY, null, values);
    }

    public Cursor queryInventory(String searchTerm) {
        String selection = null;
        String[] selectionArgs = null;
        if (searchTerm != null && !searchTerm.trim().isEmpty()) {
            selection = ITEM_NAME + " LIKE ? ESCAPE '\\'";
            selectionArgs = new String[]{"%" + escapeLike(searchTerm.trim()) + "%"};
        }
        return getReadableDatabase().query(TABLE_INVENTORY,
                new String[]{ITEM_ID, ITEM_NAME, ITEM_QUANTITY, ITEM_LOW_THRESHOLD},
                selection, selectionArgs, null, null, ITEM_NAME + " ASC");
    }

    public int updateInventoryItem(int id, ContentValues values) {
        return getWritableDatabase().update(TABLE_INVENTORY, values,
                ITEM_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int deleteInventoryItem(int id) {
        return getWritableDatabase().delete(TABLE_INVENTORY,
                ITEM_ID + " = ?", new String[]{String.valueOf(id)});
    }

    private String escapeLike(String value) {
        return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }
}
