"""Read-only real MongoDB verification. Run after an administrator creates indexes."""
import json
from CRUD_Python_Module import AnimalShelter

def summary(plan):
    stats=plan.get('executionStats',{})
    return {key:stats.get(key) for key in ('nReturned','totalKeysExamined','totalDocsExamined','executionTimeMillis')}

if __name__=='__main__':
    shelter=AnimalShelter()
    try:
        shelter.client.admin.command('ping')
        print('MongoDB connection verified')
        print('Indexes:', json.dumps(shelter.collection.index_information(),default=str,indent=2))
        query={'animal_type':'Dog','breed':{'$in':['Labrador Retriever Mix','Chesapeake Bay Retriever','Newfoundland']},
               'sex_upon_outcome':'Intact Female','age_upon_outcome_in_weeks':{'$gte':26,'$lte':156}}
        for name,hint in [('collection_scan',{'$natural':1}),('rescue_index','rescue_lookup')]:
            command={'find':shelter.collection.name,'filter':query,'hint':hint}
            plan=shelter.database.command('explain', command, verbosity='executionStats')
            print(name, json.dumps(summary(plan)))
        print('Compare documents examined and result counts; timing alone is not a benchmark.')
    finally:
        shelter.close()
