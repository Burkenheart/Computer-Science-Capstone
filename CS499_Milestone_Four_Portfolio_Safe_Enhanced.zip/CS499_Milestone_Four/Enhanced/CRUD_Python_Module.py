"""Validated MongoDB access for the CS 499 Animal Shelter enhancement."""
import math
import os
from copy import deepcopy
from pymongo import MongoClient, ASCENDING
from pymongo.errors import PyMongoError


class DatabaseOperationError(RuntimeError):
    """Public database failure with no connection or credential details."""


class AnimalShelter:
    """CRUD API. Invalid input raises ValueError; database failures raise a safe error.

    Raw queries are a trusted developer API. UI values must use build_query().
    An injected client supports isolated tests without a production database.
    """
    def __init__(self, username=None, password=None, *, client=None):
        username = username if username is not None else os.getenv('MONGO_USERNAME')
        password = password if password is not None else os.getenv('MONGO_PASSWORD')
        if client is None:
            if not username or not password:
                raise ValueError('Set MONGO_USERNAME and MONGO_PASSWORD before connecting.')
            try:
                port = int(os.getenv('MONGO_PORT', '27017'))
                if not 1 <= port <= 65535:
                    raise ValueError
            except ValueError:
                raise ValueError('MONGO_PORT must be between 1 and 65535.') from None
            client = MongoClient(
                host=os.getenv('MONGO_HOST', 'localhost'), port=port,
                username=username, password=password,
                authSource=os.getenv('MONGO_AUTH_SOURCE', 'admin'),
                tls=os.getenv('MONGO_TLS', 'false').lower() == 'true',
                serverSelectionTimeoutMS=5000, connectTimeoutMS=5000,
            )
        self.client = client
        self.database = client[os.getenv('MONGO_DATABASE', 'aac')]
        self.collection = self.database[os.getenv('MONGO_COLLECTION', 'animals')]

    @staticmethod
    def _text(value, field):
        if not isinstance(value, str) or not value.strip() or len(value) > 200:
            raise ValueError(f'{field} must be a nonempty string of at most 200 characters.')
        return value.strip()

    @staticmethod
    def _age(value):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError('Age must be a finite nonnegative number of weeks.')
        return value

    @classmethod
    def build_query(cls, *, animal_id=None, animal_type=None, breed=None,
                    min_age=None, max_age=None):
        """Build exact matches and inclusive age bounds from validated scalar input."""
        query = {}
        for field, value in [('animal_id', animal_id), ('animal_type', animal_type), ('breed', breed)]:
            if value is not None:
                query[field] = cls._text(value, field)
        bounds = {}
        if min_age is not None:
            bounds['$gte'] = cls._age(min_age)
        if max_age is not None:
            bounds['$lte'] = cls._age(max_age)
        if min_age is not None and max_age is not None and min_age > max_age:
            raise ValueError('Minimum age cannot exceed maximum age.')
        if bounds:
            query['age_upon_outcome_in_weeks'] = bounds
        return query

    @classmethod
    def _document(cls, data, *, partial=False):
        if not isinstance(data, dict) or not data:
            raise ValueError('Document must be a nonempty dictionary.')
        def check_keys(obj):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if not isinstance(key, str) or not key or key.startswith('$') or '.' in key or key == '_id':
                        raise ValueError('Document contains an unsupported field name.')
                    check_keys(value)
            elif isinstance(obj, list):
                for value in obj:
                    check_keys(value)
        check_keys(data)
        clean = deepcopy(data)
        for field in ('animal_id', 'animal_type', 'breed'):
            if field in clean:
                clean[field] = cls._text(clean[field], field)
            elif not partial:
                raise ValueError(f'{field} is required.')
        if 'age_upon_outcome_in_weeks' in clean:
            cls._age(clean['age_upon_outcome_in_weeks'])
        return clean

    @staticmethod
    def _query(query, *, destructive=False):
        if not isinstance(query, dict):
            raise ValueError('Query must be a dictionary.')
        if destructive and not query:
            raise ValueError('Update and delete require a nonempty query.')
        return deepcopy(query)

    @staticmethod
    def _run(operation):
        try:
            return operation()
        except PyMongoError:
            raise DatabaseOperationError('Database operation failed. Check access and availability.') from None

    def create(self, data):
        clean = self._document(data)
        return self._run(lambda: self.collection.insert_one(clean).acknowledged)

    def read(self, query):
        clean = self._query(query)
        return self._run(lambda: list(self.collection.find(clean, {'_id': 0})))

    def update(self, query, new_values):
        query = self._query(query, destructive=True)
        values = self._document(new_values, partial=True)
        return self._run(lambda: self.collection.update_many(query, {'$set': values}).modified_count)

    def delete(self, query):
        query = self._query(query, destructive=True)
        return self._run(lambda: self.collection.delete_many(query).deleted_count)

    def ensure_indexes(self):
        """Explicit administrative action; nonunique ID supports multiple outcome rows."""
        specifications = [
            ('animal_id_lookup', [('animal_id', ASCENDING)]),
            ('breed_lookup', [('breed', ASCENDING)]),
            ('age_lookup', [('age_upon_outcome_in_weeks', ASCENDING)]),
            ('rescue_lookup', [('animal_type', ASCENDING), ('breed', ASCENDING),
                               ('sex_upon_outcome', ASCENDING), ('age_upon_outcome_in_weeks', ASCENDING)]),
        ]
        return [self._run(lambda keys=keys, name=name: self.collection.create_index(keys, name=name))
                for name, keys in specifications]

    def close(self):
        self.client.close()
