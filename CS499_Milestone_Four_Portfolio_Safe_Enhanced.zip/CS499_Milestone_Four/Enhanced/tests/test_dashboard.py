import importlib
import math
import unittest
from unittest.mock import patch
import mongomock
import pandas as pd
from CRUD_Python_Module import AnimalShelter

class DashboardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.db=AnimalShelter(client=mongomock.MongoClient())
        with patch('CRUD_Python_Module.AnimalShelter',return_value=cls.db):
            cls.dashboard=importlib.import_module('dashboard')
    def setUp(self):
        self.db.collection.delete_many({})
        for aid,breed,sex,age in [('A1','Labrador Retriever Mix','Intact Female',26),
                                 ('A2','German Shepherd','Intact Male',100)]:
            self.db.create(dict(animal_id=aid,animal_type='Dog',breed=breed,
                                sex_upon_outcome=sex,age_upon_outcome_in_weeks=age))
    def test_combined_filter(self):
        self.assertEqual(len(self.dashboard.load_data('Water Rescue')),1)
        self.assertTrue(self.dashboard.load_data('Water Rescue',animal_id='A2').empty)
        self.assertEqual(len(self.dashboard.load_data('Mountain or Wilderness Rescue')),1)
        self.assertEqual(len(self.dashboard.load_data('Disaster or Individual Tracking')),1)
    def test_callback_empty_invalid_and_success(self):
        data,cols,status=self.dashboard.update_dashboard('Reset',None,None,None,None,None)
        self.assertEqual(len(data),2)
        self.assertEqual(status,'2 matching records')
        data,cols,status=self.dashboard.update_dashboard('Reset',None,None,None,100,20)
        self.assertEqual(data,[])
        self.assertIn('Minimum',status)
        self.assertEqual(self.dashboard.update_dashboard('Reset','missing',None,None,None,None)[2], '0 matching records')
    def test_map_invalid_coordinates(self):
        rows=pd.DataFrame([{'location_lat':math.nan,'location_long':10},
                           {'location_lat':100,'location_long':10},
                           {'location_lat':30,'location_long':-97}])
        self.assertEqual(len(self.dashboard.build_map(rows)),1)
        self.assertEqual(len(self.dashboard.build_map(pd.DataFrame())),1)
    def test_chart_empty(self):
        self.assertEqual(list(self.dashboard.build_pie_chart(pd.DataFrame()).data[0].labels),['No Data'])

if __name__=='__main__': unittest.main()
