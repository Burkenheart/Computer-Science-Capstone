import os
import unittest
from unittest.mock import patch
import mongomock
from pymongo.errors import OperationFailure
from CRUD_Python_Module import AnimalShelter, DatabaseOperationError

class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.db = AnimalShelter(client=mongomock.MongoClient())
        self.record = dict(animal_id='A1', animal_type='Dog', breed='Labrador Retriever Mix',
                           sex_upon_outcome='Intact Female', age_upon_outcome_in_weeks=26)
    def test_crud_roundtrip(self):
        self.assertTrue(self.db.create(self.record))
        self.assertNotIn('_id', self.record)
        self.assertEqual(self.db.read({'animal_id':'A1'}), [self.record])
        self.assertEqual(self.db.update({'animal_id':'A1'}, {'breed':'Newfoundland'}), 1)
        self.assertEqual(self.db.read({})[0]['breed'], 'Newfoundland')
        self.assertEqual(self.db.delete({'animal_id':'A1'}), 1)
        self.assertEqual(self.db.read({}), [])
    def test_required_fields(self):
        for value in (None, [], {}, {'animal_id':'A1'}):
            with self.assertRaises(ValueError): self.db.create(value)
    def test_bad_fields_and_age(self):
        for values in ({'$set':{}},{'x.y':1},{'_id':'x'},{'breed':{'$ne':None}},
                       {'age_upon_outcome_in_weeks':True},{'age_upon_outcome_in_weeks':float('nan')},
                       {'nested':{'$where':'x'}}):
            with self.assertRaises(ValueError): self.db.update({'animal_id':'A1'}, values)
    def test_destructive_guard(self):
        for query in ({}, [], None):
            with self.assertRaises(ValueError): self.db.delete(query)
            with self.assertRaises(ValueError): self.db.update(query, {'breed':'Dog'})
    def test_scalar_query_validation(self):
        for values in ({'breed':{'$ne':None}}, {'min_age':-1}, {'min_age':True},
                       {'min_age':float('inf')}, {'min_age':50,'max_age':20}):
            with self.assertRaises(ValueError): self.db.build_query(**values)
    def test_filter_boundaries(self):
        for age in (25,26,156,157):
            self.db.create(dict(self.record, animal_id=str(age),age_upon_outcome_in_weeks=age))
        query=self.db.build_query(animal_type='Dog', breed='Labrador Retriever Mix',min_age=26,max_age=156)
        self.assertEqual([x['animal_id'] for x in self.db.read(query)], ['26','156'])
        self.assertEqual(self.db.read(self.db.build_query(animal_id='missing')), [])
    def test_indexes(self):
        self.assertEqual(len(self.db.ensure_indexes()), 4)
        info=self.db.collection.index_information()
        self.assertEqual(info['rescue_lookup']['key'][-1][0], 'age_upon_outcome_in_weeks')
        self.assertFalse(info['animal_id_lookup'].get('unique', False))
    def test_errors_are_sanitized(self):
        calls=[('find',lambda:self.db.read({})),('insert_one',lambda:self.db.create(self.record)),
               ('update_many',lambda:self.db.update({'animal_id':'A1'},{'breed':'x'})),
               ('delete_many',lambda:self.db.delete({'animal_id':'A1'})),
               ('create_index',self.db.ensure_indexes)]
        for method, action in calls:
            with patch.object(self.db.collection,method,side_effect=OperationFailure('SECRET password')):
                with self.assertRaises(DatabaseOperationError) as caught: action()
                self.assertNotIn('SECRET', str(caught.exception))
    def test_credentials_required(self):
        with patch.dict(os.environ,{},clear=True):
            with self.assertRaises(ValueError): AnimalShelter()
    def test_connection_configuration(self):
        with patch.dict(os.environ,{'MONGO_USERNAME':'user','MONGO_PASSWORD':'p@ss:/', 'MONGO_PORT':'27017'},clear=True):
            with patch('CRUD_Python_Module.MongoClient',return_value=mongomock.MongoClient()) as factory:
                AnimalShelter()
                self.assertEqual(factory.call_args.kwargs['password'],'p@ss:/')
        with patch.dict(os.environ,{'MONGO_USERNAME':'u','MONGO_PASSWORD':'p','MONGO_PORT':'bad'},clear=True):
            with self.assertRaises(ValueError): AnimalShelter()

if __name__=='__main__': unittest.main()
