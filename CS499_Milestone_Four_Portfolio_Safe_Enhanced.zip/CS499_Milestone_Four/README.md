# CS 499 Milestone Four Database Enhancement
Steven Valiant Burgett | October 4, 2026

## Files
- Original/: the two uploaded CS 340 files, preserved byte for byte.
- Enhanced/: validated database layer, updated notebook, shared Dash application, configuration example, requirements, automated tests, and read-only live verification script.
- TEST_RESULTS.md: executed verification and remaining live checks.

## Improvements
Environment-based credentials and deployment settings replace embedded login values. Credentials are passed as MongoClient keyword arguments, so punctuation does not corrupt a URI. Validation requires animal ID, type, and breed on new records; partial updates validate changed fields. Ages must be finite nonnegative numbers. Updates/deletes reject empty query dictionaries. Database failures produce safe exceptions instead of looking like an empty successful result. Dynamic exact-match filters and inclusive age ranges are combined with rescue filters using $and to preserve both constraints. Table, chart, and map use the filtered records. Invalid coordinates are skipped with specific exception handling. The missing logo is optional.

## Setup in Windows PowerShell
From Enhanced/:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:MONGO_USERNAME = "your_username"
$env:MONGO_PASSWORD = Read-Host "MongoDB password"
$env:MONGO_HOST = "localhost"
$env:MONGO_PORT = "27017"
$env:MONGO_DATABASE = "aac"
$env:MONGO_AUTH_SOURCE = "admin"
$env:MONGO_COLLECTION = "animals"
python dashboard.py
```
Open the local address printed by Dash. Alternatively start JupyterLab from Enhanced/ and open ProjectTwoDashboard.ipynb. Start MongoDB and use your existing AAC dataset. No dataset or logo was in the uploaded ZIP. This enhancement does not seed, migrate, or delete existing data.

.env.example documents settings; it is NOT loaded automatically. Set variables in the same shell before starting Python/Jupyter. MONGO_TLS=true enables TLS for a server configured with trusted certificates; do not disable certificate validation. The default false supports the original localhost lab. Use a read-only account for the dashboard. Use a separate appropriately authorized account for CRUD or index administration. App validation is not a substitute for MongoDB roles or server-side schema validation.

## Index administration and performance verification
Index creation is an explicit step, not performed when the dashboard starts. In Enhanced/, with an account allowed to create indexes:
```powershell
python -c "from CRUD_Python_Module import AnimalShelter; s=AnimalShelter(); print(s.ensure_indexes()); s.close()"
python verify_live.py
```
Four nonunique indexes support ID, breed, age, and compound rescue searches. Animal ID is not unique because shelter data can include repeated outcome events. The compound index leads with equality fields and ends with the age range. Its animal_type prefix supports type-only queries. Indexes increase storage and write work. No speed improvement has been measured in this environment. verify_live.py compares execution statistics for the same query with a collection scan and the named rescue index; it requires that index to exist. Evaluate real selectivity and workload before retaining every index. Documentation: https://www.mongodb.com/docs/manual/core/indexes/index-types/index-compound/ and https://www.mongodb.com/docs/languages/python/pymongo-driver/current/indexes/

## Automated checks
```powershell
python -m pip install -r requirements-dev.txt
python -m unittest discover -s tests -v
```
Tests use mongomock and injected failures; they do not connect to your database. Raw read/update/delete queries remain a trusted developer interface and are not a public query endpoint. build_query rejects operator objects from UI scalar inputs. A nonempty raw query can still match many records; carefully review destructive calls. These methods preserve update_many/delete_many behavior intentionally. Read loads all matching records; server pagination is a future scalability enhancement.

## Submission and public portfolio
Submit the technical ZIP and separate Word narrative. Review the narrative's reflection and outcome mapping against your approved Module One plan before submission. The original notebook contains an embedded credential; it is preserved for private instructor comparison. Do not publish Original/ to a public portfolio. Rotate that credential if it was used for a real account. Publish only Enhanced/ without real credentials or private data. Ignore real .env files and clear notebook outputs before publishing.

## AI acknowledgment
OpenAI ChatGPT assisted with enhancement design, code generation, automated tests, documentation, and the accompanying narrative draft. The student must review and understand the code, run it in the course environment, and revise the reflection to accurately describe personal learning.
